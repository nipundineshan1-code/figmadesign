import { createBrowserRouter } from "react-router";
import { LandingPage } from "./pages/LandingPage";
import { BrowseProperties } from "./pages/BrowseProperties";
import { PropertyDetails } from "./pages/PropertyDetails";
import { UserDashboard } from "./pages/UserDashboard";
import { AdminDashboard } from "./pages/AdminDashboard";
import { AuthorityDashboard } from "./pages/AuthorityDashboard";
import { LoginPage } from "./pages/LoginPage";
import { RegisterPage } from "./pages/RegisterPage";
import { BlockchainVerification } from "./pages/BlockchainVerification";
import { NotFound } from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: LandingPage,
  },
  {
    path: "/browse",
    Component: BrowseProperties,
  },
  {
    path: "/property/:id",
    Component: PropertyDetails,
  },
  {
    path: "/user/dashboard",
    Component: UserDashboard,
  },
  {
    path: "/admin/dashboard",
    Component: AdminDashboard,
  },
  {
    path: "/authority/dashboard",
    Component: AuthorityDashboard,
  },
  {
    path: "/login",
    Component: LoginPage,
  },
  {
    path: "/register",
    Component: RegisterPage,
  },
  {
    path: "/blockchain/:transactionId",
    Component: BlockchainVerification,
  },
  {
    path: "*",
    Component: NotFound,
  },
]);
