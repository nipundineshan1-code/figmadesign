import { Link } from "react-router";
import { Home, Shield, FileCheck, AlertTriangle, Settings, LogOut, CheckCircle, Clock } from "lucide-react";

export function AuthorityDashboard() {
  const stats = [
    { label: "Pending Approvals", value: "18", icon: Clock, color: "yellow" },
    { label: "Approved Today", value: "32", icon: CheckCircle, color: "green" },
    { label: "Rejected", value: "5", icon: AlertTriangle, color: "red" },
    { label: "Total Verified", value: "1,247", icon: Shield, color: "blue" }
  ];

  const pendingApprovals = [
    {
      id: 1,
      property: "Modern Villa",
      propertyId: "PROP-2024-001",
      owner: "John Smith",
      documentType: "Title Deed",
      submittedDate: "2024-02-15",
      location: "Downtown District",
      status: "pending"
    },
    {
      id: 2,
      property: "Suburban House",
      propertyId: "PROP-2024-002",
      owner: "Jane Doe",
      documentType: "Land Survey Report",
      submittedDate: "2024-02-14",
      location: "Suburban Area",
      status: "pending"
    },
    {
      id: 3,
      property: "Commercial Plaza",
      propertyId: "PROP-2024-003",
      owner: "ABC Corporation",
      documentType: "Building Permit",
      submittedDate: "2024-02-13",
      location: "Business District",
      status: "under_review"
    }
  ];

  const recentDecisions = [
    { property: "Luxury Estate", decision: "Approved", date: "2024-02-15", authority: "Land Registry" },
    { property: "Family Home", decision: "Approved", date: "2024-02-14", authority: "Municipal Authority" },
    { property: "Downtown Condo", decision: "Rejected", date: "2024-02-13", authority: "Building Department" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-700"></div>
      </div>

      {/* Header */}
      <header className="relative z-10 backdrop-blur-md bg-white/10 border-b border-white/20">
        <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
          <Link to="/" className="flex items-center gap-2">
            <Shield className="w-8 h-8 text-blue-300" />
            <span className="text-2xl font-bold text-white">PlotFinder Authority</span>
          </Link>
          <div className="flex items-center gap-4">
            <span className="text-blue-200">Authority Portal</span>
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold">
              L
            </div>
          </div>
        </nav>
      </header>

      <div className="container mx-auto px-6 py-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
              <nav className="space-y-2">
                <Link to="/authority/dashboard" className="flex items-center gap-3 px-4 py-3 bg-white/20 text-white rounded-xl border border-white/30">
                  <Home className="w-5 h-5" />
                  <span>Dashboard</span>
                </Link>
                <Link to="/authority/approvals" className="flex items-center gap-3 px-4 py-3 text-blue-200 hover:bg-white/10 rounded-xl">
                  <FileCheck className="w-5 h-5" />
                  <span>Approvals</span>
                </Link>
                <Link to="/authority/verified" className="flex items-center gap-3 px-4 py-3 text-blue-200 hover:bg-white/10 rounded-xl">
                  <Shield className="w-5 h-5" />
                  <span>Verified</span>
                </Link>
                <Link to="/authority/settings" className="flex items-center gap-3 px-4 py-3 text-blue-200 hover:bg-white/10 rounded-xl">
                  <Settings className="w-5 h-5" />
                  <span>Settings</span>
                </Link>
                <Link to="/login" className="flex items-center gap-3 px-4 py-3 text-red-300 hover:bg-red-500/20 rounded-xl">
                  <LogOut className="w-5 h-5" />
                  <span>Logout</span>
                </Link>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-4 space-y-6">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Authority Dashboard</h1>
              <p className="text-blue-200">Review and approve property documents and verifications</p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
                  <div className="flex items-center justify-between mb-3">
                    <stat.icon className="w-10 h-10 text-blue-300" />
                  </div>
                  <p className="text-sm text-blue-200 mb-1">{stat.label}</p>
                  <p className="text-3xl font-bold text-white">{stat.value}</p>
                </div>
              ))}
            </div>

            {/* Pending Approvals */}
            <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-white">Pending Approvals</h2>
                <span className="px-3 py-1 bg-yellow-500/30 text-yellow-200 rounded-full text-sm font-medium border border-yellow-400/50">
                  {pendingApprovals.length} pending
                </span>
              </div>
              <div className="space-y-4">
                {pendingApprovals.map((approval) => (
                  <div key={approval.id} className="backdrop-blur-sm bg-white/5 border border-white/10 rounded-xl p-5 hover:bg-white/10 transition-all">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="text-lg font-semibold text-white mb-1">{approval.property}</h3>
                        <p className="text-sm text-blue-200">Property ID: {approval.propertyId}</p>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium backdrop-blur-sm ${
                        approval.status === 'pending'
                          ? 'bg-yellow-500/30 text-yellow-200 border border-yellow-400/50'
                          : 'bg-blue-500/30 text-blue-200 border border-blue-400/50'
                      }`}>
                        {approval.status === 'pending' ? 'Pending Review' : 'Under Review'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-blue-300">Owner</p>
                        <p className="text-sm font-medium text-white">{approval.owner}</p>
                      </div>
                      <div>
                        <p className="text-xs text-blue-300">Document Type</p>
                        <p className="text-sm font-medium text-white">{approval.documentType}</p>
                      </div>
                      <div>
                        <p className="text-xs text-blue-300">Location</p>
                        <p className="text-sm font-medium text-white">{approval.location}</p>
                      </div>
                      <div>
                        <p className="text-xs text-blue-300">Submitted</p>
                        <p className="text-sm font-medium text-white">{approval.submittedDate}</p>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <button className="flex-1 px-4 py-2 bg-gradient-to-r from-blue-500/30 to-blue-600/30 border border-blue-400/30 text-white rounded-xl hover:from-blue-500/40 hover:to-blue-600/40 transition-all">
                        Review Documents
                      </button>
                      <button className="px-4 py-2 bg-green-500/30 text-green-200 rounded-xl hover:bg-green-500/40 transition-all border border-green-400/50 flex items-center gap-2">
                        <CheckCircle className="w-4 h-4" />
                        Approve
                      </button>
                      <button className="px-4 py-2 bg-red-500/30 text-red-200 rounded-xl hover:bg-red-500/40 transition-all border border-red-400/50 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4" />
                        Reject
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Decisions */}
            <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
              <h2 className="text-xl font-semibold text-white mb-4">Recent Decisions</h2>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-white/10">
                      <th className="text-left py-3 px-4 text-sm font-medium text-blue-200">Property</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-blue-200">Decision</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-blue-200">Date</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-blue-200">Authority</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-blue-200">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentDecisions.map((decision, index) => (
                      <tr key={index} className="border-b border-white/5 hover:bg-white/5">
                        <td className="py-3 px-4 font-medium text-white">{decision.property}</td>
                        <td className="py-3 px-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-medium backdrop-blur-sm ${
                            decision.decision === 'Approved'
                              ? 'bg-green-500/30 text-green-200 border border-green-400/50'
                              : 'bg-red-500/30 text-red-200 border border-red-400/50'
                          }`}>
                            {decision.decision}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-blue-200">{decision.date}</td>
                        <td className="py-3 px-4 text-blue-200">{decision.authority}</td>
                        <td className="py-3 px-4">
                          <button className="text-blue-300 hover:text-blue-200 text-sm">View Details</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Blockchain Integration Notice */}
            <div className="backdrop-blur-lg bg-gradient-to-r from-blue-500/30 to-purple-500/30 rounded-2xl border border-white/30 p-6 shadow-xl">
              <div className="flex items-start gap-4">
                <Shield className="w-12 h-12 flex-shrink-0 text-blue-300" />
                <div>
                  <h3 className="text-xl font-semibold text-white mb-2">Blockchain Integration</h3>
                  <p className="text-blue-100 mb-4">
                    All approvals and verifications are automatically recorded on the blockchain to ensure transparency and immutability of property records.
                  </p>
                  <button className="px-6 py-2 bg-white/20 backdrop-blur-sm text-white rounded-xl hover:bg-white/30 transition-all border border-white/30">
                    View Blockchain Records
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
