import { Link, useParams } from "react-router";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Home, MapPin, Square, Bed, Bath, Calendar, Shield, FileText, ChevronLeft } from "lucide-react";

export function PropertyDetails() {
  const { id } = useParams();

  const property = {
    id: id,
    title: "Modern Villa",
    location: "123 Downtown District, Metro City",
    price: 450000,
    area: "3,200 sq ft",
    bedrooms: 4,
    bathrooms: 3,
    yearBuilt: 2022,
    type: "Residential",
    status: "verified",
    image: "https://images.unsplash.com/photo-1628012209120-d9db7abf7eab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
    description: "Beautiful modern villa featuring contemporary architecture with spacious living areas, high ceilings, and premium finishes throughout. This property includes a landscaped garden, private parking, and smart home features.",
    features: [
      "Central Air Conditioning",
      "Smart Home System",
      "Private Garden",
      "2-Car Garage",
      "Security System",
      "High-Speed Internet",
      "Solar Panels",
      "Modern Kitchen"
    ],
    documents: [
      { name: "Property Title Deed", status: "verified", date: "2024-01-15" },
      { name: "Land Survey Report", status: "verified", date: "2024-01-20" },
      { name: "Building Inspection", status: "verified", date: "2024-02-01" },
      { name: "Tax Assessment", status: "pending", date: "2024-02-10" }
    ],
    blockchain: {
      transactionId: "0x7a8f9b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a",
      blockNumber: "15234567",
      timestamp: "2024-02-15 14:30:00",
      verified: true
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-700"></div>
      </div>

      {/* Header */}
      <header className="relative z-10 backdrop-blur-md bg-white/10 border-b border-white/20">
        <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
          <Link to="/" className="flex items-center gap-2">
            <Home className="w-8 h-8 text-blue-300" />
            <span className="text-2xl font-bold text-white">PlotFinder</span>
          </Link>
          <div className="flex gap-4">
            <Link to="/browse" className="text-blue-200 hover:text-white">Browse</Link>
            <Link to="/login" className="text-blue-200 hover:text-white">Login</Link>
          </div>
        </nav>
      </header>

      <div className="container mx-auto px-6 py-8 relative z-10">
        {/* Back Button */}
        <Link to="/browse" className="flex items-center gap-2 text-blue-300 hover:text-blue-200 mb-6">
          <ChevronLeft className="w-5 h-5" />
          Back to Browse
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Image Gallery */}
            <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 overflow-hidden shadow-xl">
              <ImageWithFallback
                src={property.image}
                alt={property.title}
                className="w-full h-96 object-cover"
              />
            </div>

            {/* Property Info */}
            <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">{property.title}</h1>
                  <div className="flex items-center text-blue-200">
                    <MapPin className="w-5 h-5 mr-2" />
                    <span>{property.location}</span>
                  </div>
                </div>
                <span className={`px-4 py-2 rounded-full text-sm font-medium backdrop-blur-sm ${
                  property.status === 'verified'
                    ? 'bg-green-500/30 text-green-200 border border-green-400/50'
                    : 'bg-yellow-500/30 text-yellow-200 border border-yellow-400/50'
                }`}>
                  <Shield className="w-4 h-4 inline mr-1" />
                  {property.status === 'verified' ? 'Blockchain Verified' : 'Pending Verification'}
                </span>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-6 border-y border-white/20">
                <div className="flex items-center gap-3">
                  <Bed className="w-6 h-6 text-blue-300" />
                  <div>
                    <p className="text-sm text-blue-200">Bedrooms</p>
                    <p className="font-semibold text-white">{property.bedrooms}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Bath className="w-6 h-6 text-blue-300" />
                  <div>
                    <p className="text-sm text-blue-200">Bathrooms</p>
                    <p className="font-semibold text-white">{property.bathrooms}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Square className="w-6 h-6 text-blue-300" />
                  <div>
                    <p className="text-sm text-blue-200">Area</p>
                    <p className="font-semibold text-white">{property.area}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="w-6 h-6 text-blue-300" />
                  <div>
                    <p className="text-sm text-blue-200">Year Built</p>
                    <p className="font-semibold text-white">{property.yearBuilt}</p>
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <h2 className="text-xl font-semibold text-white mb-3">Description</h2>
                <p className="text-blue-100 leading-relaxed">{property.description}</p>
              </div>

              <div className="mt-6">
                <h2 className="text-xl font-semibold text-white mb-3">Features & Amenities</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {property.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2 text-blue-100">
                      <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Documents */}
            <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
              <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                <FileText className="w-6 h-6" />
                Property Documents
              </h2>
              <div className="space-y-3">
                {property.documents.map((doc, index) => (
                  <div key={index} className="flex items-center justify-between p-4 backdrop-blur-sm bg-white/5 border border-white/10 rounded-xl">
                    <div>
                      <p className="font-medium text-white">{doc.name}</p>
                      <p className="text-sm text-blue-200">Last updated: {doc.date}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium backdrop-blur-sm ${
                      doc.status === 'verified'
                        ? 'bg-green-500/30 text-green-200 border border-green-400/50'
                        : 'bg-yellow-500/30 text-yellow-200 border border-yellow-400/50'
                    }`}>
                      {doc.status === 'verified' ? '✓ Verified' : 'Pending'}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Blockchain Verification */}
            <div className="backdrop-blur-lg bg-gradient-to-r from-blue-500/30 to-purple-500/30 rounded-2xl border border-white/30 p-6 shadow-xl">
              <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                <Shield className="w-6 h-6" />
                Blockchain Verification
              </h2>
              <div className="space-y-3">
                <div>
                  <p className="text-blue-100 text-sm">Transaction ID</p>
                  <p className="font-mono text-sm text-white break-all">{property.blockchain.transactionId}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-blue-100 text-sm">Block Number</p>
                    <p className="font-semibold text-white">{property.blockchain.blockNumber}</p>
                  </div>
                  <div>
                    <p className="text-blue-100 text-sm">Timestamp</p>
                    <p className="font-semibold text-white">{property.blockchain.timestamp}</p>
                  </div>
                </div>
                <Link
                  to={`/blockchain/${property.blockchain.transactionId}`}
                  className="inline-block mt-4 px-6 py-2 bg-white/20 backdrop-blur-sm text-white rounded-xl hover:bg-white/30 transition-all border border-white/30"
                >
                  View Full Blockchain Details
                </Link>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 sticky top-24 shadow-xl">
              <p className="text-4xl font-bold text-white mb-6">${property.price.toLocaleString()}</p>

              <div className="space-y-3 mb-6">
                <button className="w-full px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all shadow-lg shadow-blue-500/50">
                  Schedule Viewing
                </button>
                <button className="w-full px-6 py-3 backdrop-blur-sm bg-white/20 text-white rounded-xl hover:bg-white/30 transition-all border border-white/30">
                  Make an Offer
                </button>
                <button className="w-full px-6 py-3 backdrop-blur-sm bg-white/10 text-blue-200 rounded-xl hover:bg-white/15 transition-all border border-white/20">
                  Contact Agent
                </button>
              </div>

              <div className="border-t border-white/20 pt-6">
                <h3 className="font-semibold text-white mb-3">Property Details</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-blue-200">Property ID:</span>
                    <span className="font-medium text-white">#{property.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-200">Type:</span>
                    <span className="font-medium text-white">{property.type}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-blue-200">Status:</span>
                    <span className="font-medium text-green-300">Available</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
