import { Link } from "react-router";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Search, Shield, FileCheck, Home } from "lucide-react";

export function LandingPage() {
  const features = [
    {
      icon: Search,
      title: "Smart Property Search",
      description: "Find your perfect plot with advanced filtering and real-time availability"
    },
    {
      icon: Shield,
      title: "Blockchain Security",
      description: "All transactions verified and secured on the blockchain"
    },
    {
      icon: FileCheck,
      title: "Document Verification",
      description: "Automated document validation and secure storage"
    },
    {
      icon: Home,
      title: "Property Management",
      description: "Complete property lifecycle management for all stakeholders"
    }
  ];

  const properties = [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1628012209120-d9db7abf7eab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
      title: "Modern Villa",
      location: "Downtown District",
      price: "$450,000",
      status: "verified"
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1721815693498-cc28507c0ba2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
      title: "Contemporary House",
      location: "Suburban Area",
      price: "$380,000",
      status: "verified"
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1523217582562-09d0def993a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
      title: "Luxury Estate",
      location: "Prime Location",
      price: "$620,000",
      status: "pending"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-700"></div>
      </div>
      {/* Hero Section */}
      <header className="relative z-10 text-white">
        <nav className="container mx-auto px-6 py-4">
          <div className="backdrop-blur-md bg-white/10 rounded-2xl border border-white/20 px-6 py-4 flex justify-between items-center shadow-lg">
            <div className="flex items-center gap-2">
              <Home className="w-8 h-8" />
              <span className="text-2xl font-bold">PlotFinder</span>
            </div>
            <div className="flex gap-4">
              <Link to="/browse" className="hover:text-blue-200 transition-colors">Browse</Link>
              <Link to="/login" className="hover:text-blue-200 transition-colors">Login</Link>
              <Link to="/register" className="px-4 py-2 bg-white/20 backdrop-blur-sm rounded-lg hover:bg-white/30 transition-all border border-white/30">Register</Link>
            </div>
          </div>
        </nav>

        <div className="container mx-auto px-6 py-20 text-center relative">
          <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-white via-blue-100 to-white bg-clip-text text-transparent">Find Your Perfect Property</h1>
          <p className="text-xl mb-8 text-blue-100">Blockchain-secured property transactions with verified documentation</p>
          <div className="max-w-2xl mx-auto flex gap-4">
            <input
              type="text"
              placeholder="Search by location, property type, or ID..."
              className="flex-1 px-6 py-4 rounded-xl backdrop-blur-md bg-white/10 border border-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/30"
            />
            <button className="px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all flex items-center gap-2 shadow-lg shadow-blue-500/50">
              <Search className="w-5 h-5" />
              Search
            </button>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-20 relative z-10">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-12 text-white">Why Choose PlotFinder?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="backdrop-blur-lg bg-white/10 p-6 rounded-2xl border border-white/20 hover:bg-white/15 transition-all hover:scale-105 shadow-xl">
                <feature.icon className="w-12 h-12 text-blue-300 mb-4" />
                <h3 className="text-xl font-semibold mb-2 text-white">{feature.title}</h3>
                <p className="text-blue-100">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="py-20 relative z-10">
        <div className="container mx-auto px-6">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-4xl font-bold text-white">Featured Properties</h2>
            <Link to="/browse" className="text-blue-300 hover:text-blue-200 flex items-center gap-2">
              View All Properties
              <span>→</span>
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {properties.map((property) => (
              <Link
                key={property.id}
                to={`/property/${property.id}`}
                className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 hover:bg-white/15 transition-all hover:scale-105 overflow-hidden shadow-xl group"
              >
                <div className="relative overflow-hidden">
                  <ImageWithFallback
                    src={property.image}
                    alt={property.title}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-semibold text-white">{property.title}</h3>
                    <span className={`px-3 py-1 rounded-full text-xs backdrop-blur-sm ${
                      property.status === 'verified'
                        ? 'bg-green-500/30 text-green-200 border border-green-400/50'
                        : 'bg-yellow-500/30 text-yellow-200 border border-yellow-400/50'
                    }`}>
                      {property.status === 'verified' ? '✓ Verified' : 'Pending'}
                    </span>
                  </div>
                  <p className="text-blue-200 mb-4">{property.location}</p>
                  <p className="text-2xl font-bold text-white">{property.price}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 py-12">
        <div className="container mx-auto px-6">
          <div className="backdrop-blur-lg bg-white/5 rounded-2xl border border-white/10 p-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <Home className="w-6 h-6 text-blue-300" />
                  <span className="text-xl font-bold text-white">PlotFinder</span>
                </div>
                <p className="text-blue-200">Blockchain-secured property management</p>
              </div>
              <div>
                <h4 className="font-semibold mb-4 text-white">For Users</h4>
                <ul className="space-y-2 text-blue-200">
                  <li><Link to="/browse" className="hover:text-white transition-colors">Browse Properties</Link></li>
                  <li><Link to="/user/dashboard" className="hover:text-white transition-colors">My Dashboard</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4 text-white">For Professionals</h4>
                <ul className="space-y-2 text-blue-200">
                  <li><Link to="/admin/dashboard" className="hover:text-white transition-colors">Admin Portal</Link></li>
                  <li><Link to="/authority/dashboard" className="hover:text-white transition-colors">Authority Portal</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-4 text-white">Legal</h4>
                <ul className="space-y-2 text-blue-200">
                  <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                  <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
                </ul>
              </div>
            </div>
            <div className="border-t border-white/10 pt-8 text-center text-blue-200">
              <p>© 2026 PlotFinder. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
