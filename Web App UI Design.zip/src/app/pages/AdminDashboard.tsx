import { Link } from "react-router";
import { Home, Users, FileText, Shield, Settings, LogOut, BarChart3, AlertCircle, CheckCircle } from "lucide-react";

export function AdminDashboard() {
  const stats = [
    { label: "Total Properties", value: "1,234", change: "+12%", icon: Home, color: "blue" },
    { label: "Active Users", value: "8,456", change: "+8%", icon: Users, color: "green" },
    { label: "Pending Verifications", value: "42", change: "-5%", icon: AlertCircle, color: "yellow" },
    { label: "Completed Transactions", value: "567", change: "+15%", icon: CheckCircle, color: "purple" }
  ];

  const pendingVerifications = [
    { id: 1, property: "Modern Villa", user: "John Smith", type: "Title Deed", date: "2024-02-15", priority: "high" },
    { id: 2, property: "Suburban House", user: "Jane Doe", type: "Land Survey", date: "2024-02-14", priority: "medium" },
    { id: 3, property: "Downtown Condo", user: "Bob Johnson", type: "Tax Assessment", date: "2024-02-13", priority: "low" }
  ];

  const recentActivities = [
    { action: "Property verified", user: "Admin User", property: "Luxury Estate", time: "2 hours ago" },
    { action: "New user registered", user: "Alice Brown", property: "-", time: "3 hours ago" },
    { action: "Document approved", user: "Admin User", property: "Modern Villa", time: "5 hours ago" },
    { action: "Property listed", user: "John Smith", property: "Family Home", time: "1 day ago" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-700"></div>
      </div>

      {/* Header */}
      <header className="relative z-10 backdrop-blur-md bg-white/10 border-b border-white/20">
        <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
          <Link to="/" className="flex items-center gap-2">
            <Home className="w-8 h-8 text-blue-300" />
            <span className="text-2xl font-bold text-white">PlotFinder Admin</span>
          </Link>
          <div className="flex items-center gap-4">
            <span className="text-blue-200">Admin Portal</span>
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold">
              A
            </div>
          </div>
        </nav>
      </header>

      <div className="container mx-auto px-6 py-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
              <nav className="space-y-2">
                <Link to="/admin/dashboard" className="flex items-center gap-3 px-4 py-3 bg-white/20 text-white rounded-xl border border-white/30">
                  <BarChart3 className="w-5 h-5" />
                  <span>Dashboard</span>
                </Link>
                <Link to="/admin/properties" className="flex items-center gap-3 px-4 py-3 text-blue-200 hover:bg-white/10 rounded-xl">
                  <Home className="w-5 h-5" />
                  <span>Properties</span>
                </Link>
                <Link to="/admin/users" className="flex items-center gap-3 px-4 py-3 text-blue-200 hover:bg-white/10 rounded-xl">
                  <Users className="w-5 h-5" />
                  <span>Users</span>
                </Link>
                <Link to="/admin/verifications" className="flex items-center gap-3 px-4 py-3 text-blue-200 hover:bg-white/10 rounded-xl">
                  <Shield className="w-5 h-5" />
                  <span>Verifications</span>
                </Link>
                <Link to="/admin/documents" className="flex items-center gap-3 px-4 py-3 text-blue-200 hover:bg-white/10 rounded-xl">
                  <FileText className="w-5 h-5" />
                  <span>Documents</span>
                </Link>
                <Link to="/admin/settings" className="flex items-center gap-3 px-4 py-3 text-blue-200 hover:bg-white/10 rounded-xl">
                  <Settings className="w-5 h-5" />
                  <span>Settings</span>
                </Link>
                <Link to="/login" className="flex items-center gap-3 px-4 py-3 text-red-300 hover:bg-red-500/20 rounded-xl">
                  <LogOut className="w-5 h-5" />
                  <span>Logout</span>
                </Link>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-4 space-y-6">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Admin Dashboard</h1>
              <p className="text-blue-200">Manage properties, users, and verifications</p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
                  <div className="flex items-center justify-between mb-3">
                    <stat.icon className="w-10 h-10 text-blue-300 opacity-70" />
                    <span className={`text-sm font-medium ${
                      stat.change.startsWith('+') ? 'text-green-300' : 'text-red-300'
                    }`}>
                      {stat.change}
                    </span>
                  </div>
                  <p className="text-sm text-blue-200 mb-1">{stat.label}</p>
                  <p className="text-3xl font-bold text-white">{stat.value}</p>
                </div>
              ))}
            </div>

            {/* Pending Verifications */}
            <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-white">Pending Verifications</h2>
                <Link to="/admin/verifications" className="text-blue-300 hover:text-blue-200 text-sm">
                  View All
                </Link>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-white/10">
                      <th className="text-left py-3 px-4 text-sm font-medium text-blue-200">Property</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-blue-200">User</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-blue-200">Document Type</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-blue-200">Date</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-blue-200">Priority</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-blue-200">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pendingVerifications.map((item) => (
                      <tr key={item.id} className="border-b border-white/5 hover:bg-white/5">
                        <td className="py-3 px-4 font-medium text-white">{item.property}</td>
                        <td className="py-3 px-4 text-blue-200">{item.user}</td>
                        <td className="py-3 px-4 text-blue-200">{item.type}</td>
                        <td className="py-3 px-4 text-blue-200">{item.date}</td>
                        <td className="py-3 px-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-medium backdrop-blur-sm ${
                            item.priority === 'high' ? 'bg-red-500/30 text-red-200 border border-red-400/50' :
                            item.priority === 'medium' ? 'bg-yellow-500/30 text-yellow-200 border border-yellow-400/50' :
                            'bg-green-500/30 text-green-200 border border-green-400/50'
                          }`}>
                            {item.priority}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex gap-2">
                            <button className="px-3 py-1 bg-green-500/30 text-green-200 rounded text-xs hover:bg-green-500/40 border border-green-400/50">
                              Approve
                            </button>
                            <button className="px-3 py-1 bg-red-500/30 text-red-200 rounded text-xs hover:bg-red-500/40 border border-red-400/50">
                              Reject
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
              <h2 className="text-xl font-semibold text-white mb-4">Recent Activity</h2>
              <div className="space-y-4">
                {recentActivities.map((activity, index) => (
                  <div key={index} className="flex items-start gap-4 pb-4 border-b border-white/10 last:border-0">
                    <div className="w-10 h-10 backdrop-blur-sm bg-white/10 rounded-full flex items-center justify-center flex-shrink-0 border border-white/20">
                      <Shield className="w-5 h-5 text-blue-300" />
                    </div>
                    <div className="flex-1">
                      <p className="text-white">
                        <span className="font-medium">{activity.action}</span>
                        {activity.property !== '-' && (
                          <> - <span className="text-blue-300">{activity.property}</span></>
                        )}
                      </p>
                      <p className="text-sm text-blue-200">By {activity.user}</p>
                      <p className="text-xs text-blue-300 mt-1">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <button className="backdrop-blur-lg bg-gradient-to-r from-blue-500/30 to-blue-600/30 border border-blue-400/30 text-white rounded-xl p-4 hover:from-blue-500/40 hover:to-blue-600/40 transition-all flex items-center gap-3 shadow-lg">
                <Home className="w-6 h-6" />
                <span className="font-medium">Add New Property</span>
              </button>
              <button className="backdrop-blur-lg bg-gradient-to-r from-green-500/30 to-green-600/30 border border-green-400/30 text-white rounded-xl p-4 hover:from-green-500/40 hover:to-green-600/40 transition-all flex items-center gap-3 shadow-lg">
                <Users className="w-6 h-6" />
                <span className="font-medium">Manage Users</span>
              </button>
              <button className="backdrop-blur-lg bg-gradient-to-r from-purple-500/30 to-purple-600/30 border border-purple-400/30 text-white rounded-xl p-4 hover:from-purple-500/40 hover:to-purple-600/40 transition-all flex items-center gap-3 shadow-lg">
                <FileText className="w-6 h-6" />
                <span className="font-medium">Review Documents</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
