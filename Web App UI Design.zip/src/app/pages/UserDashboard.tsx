import { Link } from "react-router";
import { Home, Heart, FileText, Bell, User, Settings, LogOut, MapPin, Shield } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function UserDashboard() {
  const savedProperties = [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1628012209120-d9db7abf7eab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      title: "Modern Villa",
      location: "Downtown District",
      price: 450000,
      status: "verified"
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1721815693498-cc28507c0ba2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      title: "Contemporary House",
      location: "Suburban Area",
      price: 380000,
      status: "verified"
    }
  ];

  const myProperties = [
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1523217582562-09d0def993a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=400",
      title: "Luxury Estate",
      location: "Prime Location",
      price: 620000,
      status: "verified",
      listingDate: "2024-01-15"
    }
  ];

  const recentActivity = [
    { action: "Saved property", property: "Modern Villa", date: "2024-02-15" },
    { action: "Scheduled viewing", property: "Contemporary House", date: "2024-02-14" },
    { action: "Document uploaded", property: "Luxury Estate", date: "2024-02-10" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-700"></div>
      </div>

      {/* Header */}
      <header className="relative z-10 backdrop-blur-md bg-white/10 border-b border-white/20">
        <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
          <Link to="/" className="flex items-center gap-2">
            <Home className="w-8 h-8 text-blue-300" />
            <span className="text-2xl font-bold text-white">PlotFinder</span>
          </Link>
          <div className="flex items-center gap-6">
            <Link to="/browse" className="text-blue-200 hover:text-white">Browse</Link>
            <div className="relative">
              <Bell className="w-6 h-6 text-blue-200 cursor-pointer hover:text-white" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">3</span>
            </div>
            <div className="flex items-center gap-2 text-white">
              <User className="w-6 h-6" />
              <span className="font-medium">John Doe</span>
            </div>
          </div>
        </nav>
      </header>

      <div className="container mx-auto px-6 py-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
              <div className="text-center mb-6">
                <div className="w-20 h-20 backdrop-blur-sm bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3 border border-white/30">
                  <User className="w-10 h-10 text-blue-300" />
                </div>
                <h2 className="font-semibold text-white">John Doe</h2>
                <p className="text-sm text-blue-200">john.doe@email.com</p>
              </div>

              <nav className="space-y-2">
                <Link to="/user/dashboard" className="flex items-center gap-3 px-4 py-3 bg-white/20 text-white rounded-xl border border-white/30">
                  <Home className="w-5 h-5" />
                  <span>Dashboard</span>
                </Link>
                <Link to="/user/saved" className="flex items-center gap-3 px-4 py-3 text-blue-200 hover:bg-white/10 rounded-xl">
                  <Heart className="w-5 h-5" />
                  <span>Saved Properties</span>
                </Link>
                <Link to="/user/documents" className="flex items-center gap-3 px-4 py-3 text-blue-200 hover:bg-white/10 rounded-xl">
                  <FileText className="w-5 h-5" />
                  <span>My Documents</span>
                </Link>
                <Link to="/user/settings" className="flex items-center gap-3 px-4 py-3 text-blue-200 hover:bg-white/10 rounded-xl">
                  <Settings className="w-5 h-5" />
                  <span>Settings</span>
                </Link>
                <Link to="/login" className="flex items-center gap-3 px-4 py-3 text-red-300 hover:bg-red-500/20 rounded-xl">
                  <LogOut className="w-5 h-5" />
                  <span>Logout</span>
                </Link>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-blue-200 mb-1">Saved Properties</p>
                    <p className="text-3xl font-bold text-white">{savedProperties.length}</p>
                  </div>
                  <Heart className="w-12 h-12 text-blue-300 opacity-50" />
                </div>
              </div>
              <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-blue-200 mb-1">My Properties</p>
                    <p className="text-3xl font-bold text-white">{myProperties.length}</p>
                  </div>
                  <Home className="w-12 h-12 text-green-300 opacity-50" />
                </div>
              </div>
              <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-blue-200 mb-1">Verified Docs</p>
                    <p className="text-3xl font-bold text-white">4</p>
                  </div>
                  <Shield className="w-12 h-12 text-purple-300 opacity-50" />
                </div>
              </div>
            </div>

            {/* Saved Properties */}
            <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-white">Saved Properties</h2>
                <Link to="/user/saved" className="text-blue-300 hover:text-blue-200 text-sm">View All</Link>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {savedProperties.map((property) => (
                  <Link
                    key={property.id}
                    to={`/property/${property.id}`}
                    className="backdrop-blur-sm bg-white/5 border border-white/10 rounded-xl overflow-hidden hover:bg-white/10 transition-all group"
                  >
                    <div className="relative overflow-hidden">
                      <ImageWithFallback
                        src={property.image}
                        alt={property.title}
                        className="w-full h-32 object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                    </div>
                    <div className="p-4">
                      <h3 className="font-semibold text-white mb-1">{property.title}</h3>
                      <div className="flex items-center text-sm text-blue-200 mb-2">
                        <MapPin className="w-4 h-4 mr-1" />
                        {property.location}
                      </div>
                      <p className="text-lg font-bold text-white">${property.price.toLocaleString()}</p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            {/* My Properties */}
            <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-white">My Properties</h2>
                <button className="px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 text-sm shadow-lg shadow-blue-500/50">
                  + Add Property
                </button>
              </div>
              <div className="space-y-4">
                {myProperties.map((property) => (
                  <div key={property.id} className="backdrop-blur-sm bg-white/5 border border-white/10 rounded-xl p-4 flex gap-4">
                    <div className="relative overflow-hidden rounded-lg">
                      <ImageWithFallback
                        src={property.image}
                        alt={property.title}
                        className="w-24 h-24 object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-semibold text-white">{property.title}</h3>
                          <p className="text-sm text-blue-200">{property.location}</p>
                        </div>
                        <span className="px-3 py-1 bg-green-500/30 text-green-200 text-xs rounded-full border border-green-400/50">
                          ✓ Verified
                        </span>
                      </div>
                      <p className="text-lg font-bold text-white mb-2">${property.price.toLocaleString()}</p>
                      <p className="text-xs text-blue-200">Listed on {property.listingDate}</p>
                    </div>
                    <div className="flex flex-col gap-2">
                      <button className="px-4 py-2 backdrop-blur-sm bg-white/10 border border-white/20 rounded-xl hover:bg-white/20 text-sm text-white">
                        Edit
                      </button>
                      <Link to={`/property/${property.id}`} className="px-4 py-2 backdrop-blur-sm bg-blue-500/20 border border-blue-400/30 text-blue-200 rounded-xl hover:bg-blue-500/30 text-sm text-center">
                        View
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Activity */}
            <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 p-6 shadow-xl">
              <h2 className="text-xl font-semibold text-white mb-4">Recent Activity</h2>
              <div className="space-y-3">
                {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-start gap-3 pb-3 border-b border-white/10 last:border-0">
                    <div className="w-2 h-2 bg-blue-400 rounded-full mt-2"></div>
                    <div className="flex-1">
                      <p className="text-white">{activity.action}: <span className="font-medium">{activity.property}</span></p>
                      <p className="text-sm text-blue-200">{activity.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
