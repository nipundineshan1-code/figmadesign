import { Link, useParams } from "react-router";
import { Home, Shield, Check, Copy, ExternalLink, ChevronLeft, Calendar, Hash, Cpu } from "lucide-react";

export function BlockchainVerification() {
  const { transactionId } = useParams();

  const blockchainData = {
    transactionHash: transactionId || "0x7a8f9b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a",
    blockNumber: "15234567",
    timestamp: "2024-02-15 14:30:00 UTC",
    status: "Confirmed",
    confirmations: 124,
    propertyId: "PROP-2024-001",
    propertyTitle: "Modern Villa",
    owner: "John Smith",
    previousOwner: "Sarah Johnson",
    transactionType: "Property Transfer",
    verifiedDocuments: [
      { name: "Title Deed", hash: "0x8a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1" },
      { name: "Land Survey Report", hash: "0x9b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2" },
      { name: "Building Inspection", hash: "0xa3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4" }
    ],
    gasUsed: "21000",
    gasFee: "0.0025 ETH",
    network: "Ethereum Mainnet"
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-700"></div>
      </div>

      {/* Header */}
      <header className="relative z-10 backdrop-blur-md bg-white/10 border-b border-white/20">
        <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
          <Link to="/" className="flex items-center gap-2">
            <Home className="w-8 h-8 text-blue-300" />
            <span className="text-2xl font-bold text-white">PlotFinder</span>
          </Link>
          <div className="flex gap-4">
            <Link to="/browse" className="text-blue-200 hover:text-white">Browse</Link>
            <Link to="/login" className="text-blue-200 hover:text-white">Login</Link>
          </div>
        </nav>
      </header>

      <div className="container mx-auto px-6 py-8 max-w-5xl relative z-10">
        {/* Back Button */}
        <Link to="/browse" className="flex items-center gap-2 text-blue-300 hover:text-blue-200 mb-6">
          <ChevronLeft className="w-5 h-5" />
          Back to Browse
        </Link>

        {/* Header Section */}
        <div className="backdrop-blur-lg bg-gradient-to-r from-blue-500/30 to-purple-500/30 rounded-2xl border border-white/30 p-8 text-white mb-8 shadow-xl">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-12 h-12" />
            <div>
              <h1 className="text-4xl font-bold">Blockchain Verification</h1>
              <p className="text-blue-100">Transaction Details & Property Record</p>
            </div>
          </div>
          <div className="flex items-center gap-2 mt-4">
            <Check className="w-6 h-6 bg-green-500 rounded-full p-1" />
            <span className="text-xl font-semibold">Transaction Confirmed</span>
          </div>
        </div>

        {/* Transaction Details */}
        <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6 mb-6">
          <h2 className="text-2xl font-semibold text-white mb-4">Transaction Information</h2>

          <div className="space-y-4">
            <div className="flex items-start justify-between py-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Hash className="w-5 h-5 text-blue-300" />
                <span className="text-blue-200">Transaction Hash</span>
              </div>
              <div className="flex items-center gap-2">
                <code className="text-sm backdrop-blur-sm bg-white/5 px-3 py-1 rounded font-mono text-white">
                  {blockchainData.transactionHash.slice(0, 20)}...{blockchainData.transactionHash.slice(-10)}
                </code>
                <button
                  onClick={() => copyToClipboard(blockchainData.transactionHash)}
                  className="p-2 hover:bg-white/10 rounded"
                >
                  <Copy className="w-4 h-4 text-blue-200" />
                </button>
              </div>
            </div>

            <div className="flex items-start justify-between py-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Cpu className="w-5 h-5 text-blue-300" />
                <span className="text-blue-200">Block Number</span>
              </div>
              <span className="font-medium text-white">{blockchainData.blockNumber}</span>
            </div>

            <div className="flex items-start justify-between py-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-300" />
                <span className="text-blue-200">Timestamp</span>
              </div>
              <span className="font-medium text-white">{blockchainData.timestamp}</span>
            </div>

            <div className="flex items-start justify-between py-3 border-b border-white/10">
              <span className="text-blue-200">Status</span>
              <span className="px-3 py-1 bg-green-500/30 text-green-200 rounded-full text-sm font-medium border border-green-400/50">
                {blockchainData.status}
              </span>
            </div>

            <div className="flex items-start justify-between py-3 border-b border-white/10">
              <span className="text-blue-200">Confirmations</span>
              <span className="font-medium text-white">{blockchainData.confirmations}</span>
            </div>

            <div className="flex items-start justify-between py-3">
              <span className="text-blue-200">Network</span>
              <span className="font-medium text-white">{blockchainData.network}</span>
            </div>
          </div>
        </div>

        {/* Property Information */}
        <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6 mb-6">
          <h2 className="text-2xl font-semibold text-white mb-4">Property Information</h2>

          <div className="space-y-4">
            <div className="flex items-start justify-between py-3 border-b border-white/10">
              <span className="text-blue-200">Property ID</span>
              <span className="font-medium text-white">{blockchainData.propertyId}</span>
            </div>

            <div className="flex items-start justify-between py-3 border-b border-white/10">
              <span className="text-blue-200">Property Title</span>
              <Link to="/property/1" className="font-medium text-blue-300 hover:text-blue-200">
                {blockchainData.propertyTitle}
              </Link>
            </div>

            <div className="flex items-start justify-between py-3 border-b border-white/10">
              <span className="text-blue-200">Transaction Type</span>
              <span className="font-medium text-white">{blockchainData.transactionType}</span>
            </div>

            <div className="flex items-start justify-between py-3 border-b border-white/10">
              <span className="text-blue-200">Current Owner</span>
              <span className="font-medium text-white">{blockchainData.owner}</span>
            </div>

            <div className="flex items-start justify-between py-3">
              <span className="text-blue-200">Previous Owner</span>
              <span className="font-medium text-white">{blockchainData.previousOwner}</span>
            </div>
          </div>
        </div>

        {/* Verified Documents */}
        <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6 mb-6">
          <h2 className="text-2xl font-semibold text-white mb-4">Verified Documents</h2>
          <p className="text-sm text-blue-200 mb-4">
            All documents have been cryptographically hashed and stored on the blockchain
          </p>

          <div className="space-y-3">
            {blockchainData.verifiedDocuments.map((doc, index) => (
              <div key={index} className="backdrop-blur-sm bg-white/5 border border-white/10 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Check className="w-5 h-5 text-green-400" />
                    <span className="font-medium text-white">{doc.name}</span>
                  </div>
                  <span className="px-2 py-1 bg-green-500/30 text-green-200 rounded text-xs font-medium border border-green-400/50">
                    Verified
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <code className="text-xs backdrop-blur-sm bg-white/5 px-2 py-1 rounded font-mono text-blue-200">
                    {doc.hash.slice(0, 30)}...{doc.hash.slice(-10)}
                  </code>
                  <button
                    onClick={() => copyToClipboard(doc.hash)}
                    className="p-1 hover:bg-white/10 rounded"
                  >
                    <Copy className="w-3 h-3 text-blue-200" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Blockchain Explorer Link */}
        <div className="backdrop-blur-lg bg-blue-500/20 border border-blue-400/30 rounded-2xl p-6 shadow-xl">
          <div className="flex items-start gap-4">
            <ExternalLink className="w-6 h-6 text-blue-300 flex-shrink-0 mt-1" />
            <div className="flex-1">
              <h3 className="font-semibold text-white mb-2">View on Blockchain Explorer</h3>
              <p className="text-sm text-blue-200 mb-4">
                Verify this transaction independently on a public blockchain explorer
              </p>
              <a
                href="#"
                className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all shadow-lg shadow-blue-500/50"
              >
                <span>Open in Etherscan</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
