import { Link } from "react-router";
import { Home, Search, AlertCircle } from "lucide-react";

export function NotFound() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 relative overflow-hidden flex items-center justify-center p-6">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-700"></div>
      </div>

      <div className="text-center max-w-md relative z-10">
        {/* Icon */}
        <div className="flex justify-center mb-6">
          <div className="w-24 h-24 backdrop-blur-lg bg-white/10 rounded-full flex items-center justify-center border border-white/20">
            <AlertCircle className="w-12 h-12 text-blue-300" />
          </div>
        </div>

        {/* Error Message */}
        <h1 className="text-8xl font-bold text-white mb-4 bg-gradient-to-r from-blue-300 to-purple-400 bg-clip-text text-transparent">404</h1>
        <h2 className="text-3xl font-semibold text-white mb-4">Page Not Found</h2>
        <p className="text-blue-200 mb-8">
          Sorry, we couldn't find the page you're looking for. The property or page you're trying to access might have been moved or doesn't exist.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            to="/"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all shadow-lg shadow-blue-500/50"
          >
            <Home className="w-5 h-5" />
            Go to Home
          </Link>
          <Link
            to="/browse"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 backdrop-blur-lg bg-white/10 text-white rounded-xl hover:bg-white/20 transition-all border border-white/20"
          >
            <Search className="w-5 h-5" />
            Browse Properties
          </Link>
        </div>

        {/* Help Text */}
        <div className="mt-12 pt-8 border-t border-white/20">
          <p className="text-sm text-blue-200">
            Need help? <a href="#" className="text-blue-300 hover:text-blue-200 font-medium">Contact support</a>
          </p>
        </div>
      </div>
    </div>
  );
}
