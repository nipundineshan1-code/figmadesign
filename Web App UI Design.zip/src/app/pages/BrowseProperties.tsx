import { useState } from "react";
import { Link } from "react-router";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Search, Filter, MapPin, Home, ChevronDown } from "lucide-react";

export function BrowseProperties() {
  const [priceRange, setPriceRange] = useState("all");
  const [propertyType, setPropertyType] = useState("all");
  const [status, setStatus] = useState("all");

  const properties = [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1628012209120-d9db7abf7eab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
      title: "Modern Villa",
      location: "Downtown District",
      price: 450000,
      area: "3,200 sq ft",
      bedrooms: 4,
      bathrooms: 3,
      type: "Residential",
      status: "verified"
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1721815693498-cc28507c0ba2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
      title: "Contemporary House",
      location: "Suburban Area",
      price: 380000,
      area: "2,800 sq ft",
      bedrooms: 3,
      bathrooms: 2,
      type: "Residential",
      status: "verified"
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1523217582562-09d0def993a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
      title: "Luxury Estate",
      location: "Prime Location",
      price: 620000,
      area: "4,500 sq ft",
      bedrooms: 5,
      bathrooms: 4,
      type: "Residential",
      status: "pending"
    },
    {
      id: 4,
      image: "https://images.unsplash.com/photo-1722421492323-eaf9c401befe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
      title: "Family Home",
      location: "Residential Zone",
      price: 320000,
      area: "2,400 sq ft",
      bedrooms: 3,
      bathrooms: 2,
      type: "Residential",
      status: "verified"
    },
    {
      id: 5,
      image: "https://images.unsplash.com/photo-1748063578185-3d68121b11ff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
      title: "Modern Residence",
      location: "Central District",
      price: 550000,
      area: "3,800 sq ft",
      bedrooms: 4,
      bathrooms: 3,
      type: "Residential",
      status: "verified"
    },
    {
      id: 6,
      image: "https://images.unsplash.com/photo-1691425700585-c108acad6467?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080",
      title: "Premium Villa",
      location: "Elite Neighborhood",
      price: 720000,
      area: "5,000 sq ft",
      bedrooms: 5,
      bathrooms: 4,
      type: "Residential",
      status: "verified"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-700"></div>
      </div>

      {/* Header */}
      <header className="relative z-10 backdrop-blur-md bg-white/10 border-b border-white/20 sticky top-0">
        <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
          <Link to="/" className="flex items-center gap-2">
            <Home className="w-8 h-8 text-blue-300" />
            <span className="text-2xl font-bold text-white">PlotFinder</span>
          </Link>
          <div className="flex gap-4">
            <Link to="/browse" className="text-blue-300">Browse</Link>
            <Link to="/login" className="text-blue-200 hover:text-white">Login</Link>
            <Link to="/register" className="px-4 py-2 bg-white/20 backdrop-blur-sm text-white rounded-lg hover:bg-white/30 border border-white/30">Register</Link>
          </div>
        </nav>
      </header>

      <div className="container mx-auto px-6 py-8 relative z-10">
        {/* Search and Filters */}
        <div className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 shadow-xl p-6 mb-8">
          <div className="flex gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-200" />
              <input
                type="text"
                placeholder="Search by location, property ID, or keywords..."
                className="w-full pl-10 pr-4 py-3 backdrop-blur-md bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/30"
              />
            </div>
            <button className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 flex items-center gap-2 shadow-lg shadow-blue-500/50">
              <Search className="w-5 h-5" />
              Search
            </button>
          </div>

          <div className="flex gap-4 flex-wrap">
            <div className="flex-1 min-w-[200px]">
              <label className="block text-sm font-medium text-blue-200 mb-2">Price Range</label>
              <select
                value={priceRange}
                onChange={(e) => setPriceRange(e.target.value)}
                className="w-full px-4 py-2 backdrop-blur-md bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-white/30"
              >
                <option value="all">All Prices</option>
                <option value="0-300000">Under $300,000</option>
                <option value="300000-500000">$300,000 - $500,000</option>
                <option value="500000-700000">$500,000 - $700,000</option>
                <option value="700000+">$700,000+</option>
              </select>
            </div>

            <div className="flex-1 min-w-[200px]">
              <label className="block text-sm font-medium text-blue-200 mb-2">Property Type</label>
              <select
                value={propertyType}
                onChange={(e) => setPropertyType(e.target.value)}
                className="w-full px-4 py-2 backdrop-blur-md bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-white/30"
              >
                <option value="all">All Types</option>
                <option value="residential">Residential</option>
                <option value="commercial">Commercial</option>
                <option value="land">Land</option>
              </select>
            </div>

            <div className="flex-1 min-w-[200px]">
              <label className="block text-sm font-medium text-blue-200 mb-2">Verification Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                className="w-full px-4 py-2 backdrop-blur-md bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-white/30"
              >
                <option value="all">All Status</option>
                <option value="verified">Verified Only</option>
                <option value="pending">Pending Verification</option>
              </select>
            </div>
          </div>
        </div>

        {/* Results Header */}
        <div className="flex justify-between items-center mb-6">
          <p className="text-blue-200">{properties.length} properties found</p>
          <select className="px-4 py-2 backdrop-blur-md bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-white/30">
            <option>Sort by: Newest</option>
            <option>Price: Low to High</option>
            <option>Price: High to Low</option>
            <option>Area: Largest First</option>
          </select>
        </div>

        {/* Property Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {properties.map((property) => (
            <Link
              key={property.id}
              to={`/property/${property.id}`}
              className="backdrop-blur-lg bg-white/10 rounded-2xl border border-white/20 hover:bg-white/15 transition-all hover:scale-105 overflow-hidden shadow-xl group"
            >
              <div className="relative overflow-hidden">
                <ImageWithFallback
                  src={property.image}
                  alt={property.title}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                <span className={`absolute top-3 right-3 px-3 py-1 rounded-full text-xs font-medium backdrop-blur-sm ${
                  property.status === 'verified'
                    ? 'bg-green-500/30 text-green-200 border border-green-400/50'
                    : 'bg-yellow-500/30 text-yellow-200 border border-yellow-400/50'
                }`}>
                  {property.status === 'verified' ? '✓ Verified' : 'Pending'}
                </span>
              </div>
              <div className="p-5">
                <h3 className="text-xl font-semibold text-white mb-2">{property.title}</h3>
                <div className="flex items-center text-blue-200 mb-3">
                  <MapPin className="w-4 h-4 mr-1" />
                  <span className="text-sm">{property.location}</span>
                </div>
                <div className="flex gap-4 text-sm text-blue-200 mb-4">
                  <span>{property.bedrooms} bed</span>
                  <span>{property.bathrooms} bath</span>
                  <span>{property.area}</span>
                </div>
                <div className="flex justify-between items-center">
                  <p className="text-2xl font-bold text-white">${property.price.toLocaleString()}</p>
                  <span className="text-sm text-blue-300">{property.type}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
