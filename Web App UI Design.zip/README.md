
  # Web App UI Design

  This is a code bundle for Web App UI Design. The original project is available at https://www.figma.com/design/5TzFwePd7NI79OGgNpaIDP/Web-App-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  